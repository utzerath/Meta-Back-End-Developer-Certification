# API-Final   
# Final Project for the API course provided by META on Coursera   

Fully functional API project covering all major topics including basic CRUD, authentication and authorization, user roles, filtering and ordering and finally throttling
